<?php 
/*****************************************************************************
*
*	copyright(c) - aonetheme.com - Service Finder Team
*	More Info: http://aonetheme.com/
*	Coder: Service Finder Team
*	Email: contact@aonetheme.com
*
******************************************************************************/
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<div class="sf-wpbody-inr">
  <?php 
  $totalfeatured = service_finder_total_featured_providers();
  $totalpaidproviders =  service_finder_total_paid_providers();
  $totalusers = count_users();
  $total = $totalusers['avail_roles']['Provider'] + $totalusers['avail_roles']['Customer'];
  $totalproviders = ($totalusers['avail_roles']['Provider'] > 0) ? $totalusers['avail_roles']['Provider'] : 0;
  $totalcustomers = ($totalusers['avail_roles']['Customer'] > 0) ? $totalusers['avail_roles']['Customer'] : 0;
  ?>
  <ul class="sf-users-stats">
	  <li><div><i class="fa fa-user"></i> <span><?php echo esc_html__('Total no of user', 'service-finder'); ?></span> <strong><?php echo esc_html($total); ?></strong></div></li>
      <li><div><i class="fa fa-user"></i> <span><?php echo esc_html__('Total no. of providers', 'service-finder'); ?></span> <strong><?php echo esc_html($totalproviders); ?></strong></div></li>
      <li><div><i class="fa fa-user"></i> <span><?php echo esc_html__('Total no. of paid providers', 'service-finder'); ?></span> <strong><?php echo esc_html($totalpaidproviders); ?></strong></div></li>
      <li><div><i class="fa fa-user"></i> <span><?php echo esc_html__('Total no. of featured providers', 'service-finder'); ?></span> <strong><?php echo esc_html($totalfeatured); ?></strong></div></li>
      <li><div><i class="fa fa-user"></i> <span><?php echo esc_html__('Total no. of customers', 'service-finder'); ?></span> <strong><?php echo esc_html($totalcustomers); ?></strong></div></li>
  </ul>
</div>
