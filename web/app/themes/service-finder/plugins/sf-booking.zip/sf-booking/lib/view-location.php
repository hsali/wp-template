<?php
/*****************************************************************************
*
*	copyright(c) - aonetheme.com - Service Finder Team
*	More Info: http://aonetheme.com/
*	Coder: Service Finder Team
*	Email: contact@aonetheme.com
*
******************************************************************************/
?>
<!-- View my location on map-->
<div class="set-marker-popup">
    <div class="set-marker-popup-close"><i class="fa fa-close"></i></div>
    <div class="set-marker-map">
        <div id="marker-map" style="position:absolute; height:100%; width:100%; top:0; left:0;"></div>
    </div>
</div>