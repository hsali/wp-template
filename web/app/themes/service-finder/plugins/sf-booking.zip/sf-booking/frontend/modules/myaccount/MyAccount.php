<?php
/*****************************************************************************
*
*	copyright(c) - aonetheme.com - Service Finder Team
*	More Info: http://aonetheme.com/
*	Coder: Service Finder Team
*	Email: contact@aonetheme.com
*
******************************************************************************/
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class SERVICE_FINDER_MyAccount{

	/*Update Provider Profile*/
	public function service_finder_updateUserProfile($arg){
			global $wpdb, $service_finder_Tables, $current_user;
			
			//Email already exist
			if($this->service_finder_custom_email_exists( esc_attr($arg['user_email']), $arg['user_id'] )){
				$error = array(
						'status' => 'error',
						'err_message' => esc_html__('Email already exist', 'service-finder'),
						);
				echo json_encode($error);
				exit;
			}
		
			
			
			
			if($arg['password'] != ""){
			$userdata = array(
						'ID' => $arg['user_id'],
						'user_email' => $arg['user_email'],
						'user_pass' => $arg['password'],
						'first_name' => $arg['first_name'],
						'last_name' => $arg['last_name'],
						);
			}else{
			$userdata = array(
						'ID' => $arg['user_id'],
						'user_email' => $arg['user_email'],
						'first_name' => $arg['first_name'],
						'last_name' => $arg['last_name'],
						);
			}			
			

			$userId = wp_update_user( $userdata );
			
			if ( ! empty($userId->errors) ) {
				$errmsg = 'Couldn&#8217;t update you... please contact the <a href="mailto:'.esc_url($adminemail).'">Administrator</a> !';
				$allowedhtml = array(
					'a' => array(
						'href' => array(),
						'title' => array()
					),
				);
				$error = array(
						'status' => 'error',
						'err_message' => sprintf( wp_kses(esc_html__('Couldn&#8217;t update you... please contact the <a href="mailto:%s">Administrator</a> !', 'service-finder'),$allowedhtml), $adminemail )
						);
				echo json_encode($error);
			}else{
			
				update_user_meta($userId, 'first_name', $arg['first_name']);
				update_user_meta($userId, 'last_name', $arg['last_name']);
				$fname = (!empty($arg['first_name'])) ? $arg['first_name'] : '';
				$lname = (!empty($arg['last_name'])) ? $arg['last_name'] : '';

				if(!empty($arg['category'])){
					$selectedcategory = implode(',',$arg['category']);
				}else{
					$selectedcategory = $arg['category'];
				}
				
				$address = (!empty($arg['address'])) ? $arg['address'] : '';
				$city = (!empty($arg['city'])) ? $arg['city'] : '';
				$state = (!empty($arg['state'])) ? $arg['state'] : '';
				$country = (!empty($arg['country'])) ? $arg['country'] : '';
				
				$tokens = array($city,$state,$country);
				$replacements = array('','','');
				$address = str_replace($tokens,$replacements,$address);
				$tokens2 = array(', ,',', , ,');
				$replacements2 = array(',',',');
				$address = str_replace($tokens2,$replacements2,$address);
				$address = rtrim($address,', ,');
				$address = rtrim($address,',');
				
				$videocount = (isset($arg['videocount'])) ? $arg['videocount'] : '';
				if($videocount == 1){
				if(empty($arg['videosarr'])){

					$row = $wpdb->get_row($wpdb->prepare('SELECT * FROM '.$service_finder_Tables->providers.' WHERE `wp_user_id` = %d',$userId));

					$embeded_code = $row->embeded_code;

				}else{

					$embeded_code = serialize($arg['videosarr']);

				}
				}else{
					$embeded_code = '';
				}
				
				/*Update Provider Table*/
				$data = array(
						'company_name' => (!empty($arg['company_name'])) ? $arg['company_name'] : '',
						'full_name' => $fname.' '.$lname,
						'avatar_id' => (!empty($arg['plavatar'])) ? $arg['plavatar'] : '',
						'phone' => (!empty($arg['phone'])) ? $arg['phone'] : '',
						'email' => (!empty($arg['user_email'])) ? $arg['user_email'] : '',
						'category_id' => $selectedcategory,
						'tagline' => (!empty($arg['tagline'])) ? $arg['tagline'] : '',
						'bio' => (!empty($arg['bio'])) ? $arg['bio'] : '',
						'booking_description' => (!empty($arg['booking_description'])) ? $arg['booking_description'] : '',
						'embeded_code' => $embeded_code,
						'mobile' => (!empty($arg['mobile'])) ? $arg['mobile'] : '',
						'fax' => (!empty($arg['fax'])) ? $arg['fax'] : '',
						'address' => $address,
						'apt' => (!empty($arg['apt'])) ? $arg['apt'] : '',
						'city' => (!empty($arg['city'])) ? $arg['city'] : '',
						'state' => (!empty($arg['state'])) ? $arg['state'] : '',
						'zipcode' => (!empty($arg['zipcode'])) ? $arg['zipcode'] : '',
						'country' => (!empty($arg['country'])) ? $arg['country'] : '',
						'lat' => (!empty($arg['lat'])) ? $arg['lat'] : '',
						'long' => (!empty($arg['long'])) ? $arg['long'] : '',
						'facebook' => (!empty($arg['facebook'])) ? $arg['facebook'] : '',
						'twitter' => (!empty($arg['twitter'])) ? $arg['twitter'] : '',
						'linkedin' => (!empty($arg['linkedin'])) ? $arg['linkedin'] : '',
						'pinterest' => (!empty($arg['pinterest'])) ? $arg['pinterest'] : '',
						'google_plus' => (!empty($arg['google_plus'])) ? $arg['google_plus'] : '',
						'digg' => (!empty($arg['digg'])) ? $arg['digg'] : '',
						'instagram' => (!empty($arg['instagram'])) ? $arg['instagram'] : '',
						'skypeid' => (!empty($arg['skypeid'])) ? $arg['skypeid'] : '',
						'website' => (!empty($arg['website'])) ? $arg['website'] : ''
						);
				
				$where = array(
						'wp_user_id' => $userId,
						);
				$proid = $wpdb->update($service_finder_Tables->providers,wp_unslash($data),$where);
				
				$bio = (!empty($arg['bio'])) ? $arg['bio'] : '';
				update_user_meta($userId,'description',$bio);
				
				$userCap = service_finder_get_capability($userId);
				
				
				if(!empty($userCap)){
					if(in_array('multiple-categories',$userCap)){
						$primarycategory = (!empty($arg['primary_category'])) ? $arg['primary_category'] : '';
					}else{
						$primarycategory = (!empty($arg['category'][0])) ? $arg['category'][0] : '';
					}
				}else{
						$primarycategory = (!empty($arg['category'][0])) ? $arg['category'][0] : '';
				}	
				
				$serviceradius = (!empty($arg['serviceradius'])) ? esc_html($arg['serviceradius']) : 0;
				
				update_user_meta($userId,'primary_category',$primarycategory);
				update_user_meta($userId,'serviceradius',$serviceradius);
				
				if(!empty($arg['attachmentid'])){
					foreach($arg['attachmentid'] as $attachmentid){
						if(!$this->service_finder_check_attachment($attachmentid)){
							$data = array(
										'wp_user_id' => $userId,
										'attachmentid' => $attachmentid,
										'type' => 'gallery'
										);
					
							$wpdb->insert($service_finder_Tables->attachments,wp_unslash($data));	
						}
					}
				}
				
				if(!empty($arg['fileattachmentid'])){
					foreach($arg['fileattachmentid'] as $fileattachmentid){
						if(!$this->service_finder_check_attachment($fileattachmentid)){
							$data = array(
										'wp_user_id' => $userId,
										'attachmentid' => $fileattachmentid,
										'type' => 'file'
										);
					
							$wpdb->insert($service_finder_Tables->attachments,wp_unslash($data));	
						}
					}
				}
				
				if(!empty($arg['coverimageattachmentid'])){
					foreach($arg['coverimageattachmentid'] as $coverimageattachmentid){
						if(!$this->service_finder_check_attachment($coverimageattachmentid)){
							$data = array(
										'wp_user_id' => $userId,
										'attachmentid' => $coverimageattachmentid,
										'type' => 'cover-image'
										);
					
							$wpdb->insert($service_finder_Tables->attachments,wp_unslash($data));	
						}
					}
				}		
				
				/*Update Member Table*/
				$memberData = array(
						'member_name' => $arg['first_name'].' '.$arg['last_name'],
						'email' => $arg['user_email'],
						'phone' => $arg['phone'],
						);
				
				$where = array(
						'admin_wp_id' => $userId,
						'is_admin' => 'yes',
						);		
		
				$wpdb->update($service_finder_Tables->team_members,wp_unslash($memberData),$where);
				
				/*Update Provider Settings*/
				$google_calendar = (!empty($arg['google_calendar'])) ? $arg['google_calendar'] : '';
				$booking_process = (!empty($arg['booking_process'])) ? $arg['booking_process'] : '';
				$availability_based_on = (!empty($arg['availability_based_on'])) ? $arg['availability_based_on'] : '';
				$booking_basedon = (!empty($arg['booking_basedon'])) ? $arg['booking_basedon'] : '';
				$booking_charge_on_service = (!empty($arg['booking_charge_on_service'])) ? $arg['booking_charge_on_service'] : '';
				$booking_option = (!empty($arg['booking_option'])) ? $arg['booking_option'] : '';
				$mincost = (isset($arg['mincost'])) ? $arg['mincost'] : '';
				$mincost = ($mincost == 0) ? '0.0' : $mincost;
				$booking_assignment = (!empty($arg['booking_assignment'])) ? $arg['booking_assignment'] : '';
				$members_available = (!empty($arg['members_available'])) ? $arg['members_available'] : '';
				$pay_options = (!empty($arg['pay_options'])) ? $arg['pay_options'] : '';
				$paypalusername = (!empty($arg['paypalusername'])) ? $arg['paypalusername'] : '';
				$paypalpassword = (!empty($arg['paypalpassword'])) ? $arg['paypalpassword'] : '';
				$paypalsignatue = (!empty($arg['paypalsignatue'])) ? $arg['paypalsignatue'] : '';
				$stripesecretkey = (!empty($arg['stripesecretkey'])) ? $arg['stripesecretkey'] : '';
				$stripepublickey = (!empty($arg['stripepublickey'])) ? $arg['stripepublickey'] : '';
				$wired_description = (!empty($arg['wired_description'])) ? $arg['wired_description'] : '';
				$wired_instructions = (!empty($arg['wired_instructions'])) ? $arg['wired_instructions'] : '';
				$twocheckoutaccountid = (!empty($arg['twocheckoutaccountid'])) ? $arg['twocheckoutaccountid'] : '';
				$twocheckoutpublishkey = (!empty($arg['twocheckoutpublishkey'])) ? $arg['twocheckoutpublishkey'] : '';
				$twocheckoutprivatekey = (!empty($arg['twocheckoutprivatekey'])) ? $arg['twocheckoutprivatekey'] : '';
				$payumoneymid = (!empty($arg['payumoneymid'])) ? $arg['payumoneymid'] : '';
				$payumoneykey = (!empty($arg['payumoneykey'])) ? $arg['payumoneykey'] : '';
				$payumoneysalt = (!empty($arg['payumoneysalt'])) ? $arg['payumoneysalt'] : '';
				$payulatammerchantid = (!empty($arg['payulatammerchantid'])) ? $arg['payulatammerchantid'] : '';
				$payulatamapilogin = (!empty($arg['payulatamapilogin'])) ? $arg['payulatamapilogin'] : '';
				$payulatamapikey = (!empty($arg['payulatamapikey'])) ? $arg['payulatamapikey'] : '';
				$payulatamaccountid = (!empty($arg['payulatamaccountid'])) ? $arg['payulatamaccountid'] : '';
				
				$zoomlevel = (!empty($arg['zoomlevel'])) ? $arg['zoomlevel'] : '';
				$locationzoomlevel = (!empty($arg['locationzoomlevel'])) ? $arg['locationzoomlevel'] : '';
				
				$service_perform = (!empty($arg['service_perform'])) ? $arg['service_perform'] : '';
				$my_location = (!empty($arg['my_location'])) ? $arg['my_location'] : '';
				$providerlat = (!empty($arg['providerlat'])) ? $arg['providerlat'] : '';
				$providerlng = (!empty($arg['providerlng'])) ? $arg['providerlng'] : '';
				
				$bank_account_holder_name = (!empty($arg['bank_account_holder_name'])) ? $arg['bank_account_holder_name'] : '';
				$bank_account_number = (!empty($arg['bank_account_number'])) ? $arg['bank_account_number'] : '';
				$swift_code = (!empty($arg['swift_code'])) ? $arg['swift_code'] : '';
				$bank_name = (!empty($arg['bank_name'])) ? $arg['bank_name'] : '';
				$bank_branch_city = (!empty($arg['bank_branch_city'])) ? $arg['bank_branch_city'] : '';
				$bank_branch_country = (!empty($arg['bank_branch_country'])) ? $arg['bank_branch_country'] : '';
				$paypal_email_id = (!empty($arg['paypal_email_id'])) ? $arg['paypal_email_id'] : '';
				
				$google_calendar_id = (!empty($arg['google_calendar_id'])) ? $arg['google_calendar_id'] : '';
				
				update_user_meta($userId,'bank_account_holder_name',$bank_account_holder_name);
				update_user_meta($userId,'bank_account_number',$bank_account_number);
				update_user_meta($userId,'swift_code',$swift_code);
				update_user_meta($userId,'bank_name',$bank_name);
				update_user_meta($userId,'bank_branch_city',$bank_branch_city);
				update_user_meta($userId,'bank_branch_country',$bank_branch_country);
				
				update_user_meta($userId,'google_calendar_id',$google_calendar_id);
				
				update_user_meta($userId,'zoomlevel',$zoomlevel);
				update_user_meta($userId,'locationzoomlevel',$locationzoomlevel);
				
				update_user_meta($userId,'paypal_email_id',$paypal_email_id);
				
				update_user_meta($userId,'service_perform',$service_perform);
				
				if($service_perform == 'provider_location'){
				update_user_meta($userId,'my_location',$my_location);
				
				if($providerlat == '' && $providerlng == ''){
				$address = str_replace(" ","+",$my_location);
				$res = service_finder_getLatLong($address);
				$providerlat = $res['lat'];
				$providerlng = $res['lng'];
				}
				
				update_user_meta($userId,'providerlat',$providerlat);
				update_user_meta($userId,'providerlng',$providerlng);
				}
				
				$options = unserialize(get_option( 'provider_settings'));
				$options[$userId] = array(
				'booking_process' => esc_html($booking_process),
				'availability_based_on' => esc_html($availability_based_on),
				'booking_basedon' => ($booking_process == 'on') ? $booking_basedon : '',
				'booking_charge_on_service' => ($booking_process == 'on') ? $booking_charge_on_service : '',
				'booking_option' => ($booking_process == 'on') ? $booking_option : '',
				'mincost' => ($booking_option == 'paid' && $booking_process == 'on') ? $mincost : '',
				'booking_assignment' => ($booking_process == 'on') ? $booking_assignment : '',
				'members_available' => ($booking_process == 'on' && $booking_assignment == 'automatically') ? $members_available : '',
				'paymentoption' => ($booking_option == 'paid' && $booking_process == 'on') ? $pay_options : '',
				'paypalusername' => ($booking_option == 'paid' && $booking_process == 'on') ? $paypalusername : '',
				'paypalpassword' => ($booking_option == 'paid' && $booking_process == 'on') ? $paypalpassword : '',
				'paypalsignatue' => ($booking_option== 'paid' && $booking_process == 'on') ? $paypalsignatue : '',
				'stripesecretkey' => ($booking_option == 'paid' && $booking_process == 'on') ? $stripesecretkey : '',
				'stripepublickey' => ($booking_option == 'paid' && $booking_process == 'on') ? $stripepublickey : '',
				'wired_description' => ($booking_option == 'paid' && $booking_process == 'on') ? $wired_description : '',
				'wired_instructions' => ($booking_option == 'paid' && $booking_process == 'on') ? $wired_description : '',
				'twocheckoutaccountid' => ($booking_option == 'paid' && $booking_process == 'on') ? $twocheckoutaccountid : '',
				'twocheckoutpublishkey' => ($booking_option == 'paid' && $booking_process == 'on') ? $twocheckoutpublishkey : '',
				'twocheckoutprivatekey' => ($booking_option == 'paid' && $booking_process == 'on') ? $twocheckoutprivatekey : '',
				'payumoneymid' => ($booking_option == 'paid' && $booking_process == 'on') ? $payumoneymid : '',
				'payumoneykey' => ($booking_option == 'paid' && $booking_process == 'on') ? $payumoneykey : '',
				'payumoneysalt' => ($booking_option == 'paid' && $booking_process == 'on') ? $payumoneysalt : '',
				'payulatammerchantid' => ($booking_option == 'paid' && $booking_process == 'on') ? $payulatammerchantid : '',
				'payulatamapilogin' => ($booking_option == 'paid' && $booking_process == 'on') ? $payulatamapilogin : '',
				'payulatamapikey' => ($booking_option == 'paid' && $booking_process == 'on') ? $payulatamapikey : '',
				'payulatamaccountid' => ($booking_option == 'paid' && $booking_process == 'on') ? $payulatamaccountid : '',
				'google_calendar' => $google_calendar,
				);
				update_option( 'provider_settings', serialize($options) );
				
				/*if($google_calendar == 'on' && $google_client_id != "" && $google_client_secret != ""){
					service_finder_connect_to_google_calendar($google_client_id,$google_client_secret);
				}*/
				
				$success = array(
						'status' => 'success',
						'suc_message' => esc_html__('Your profile updated successfully.', 'service-finder'),
						'userid' => $userId,
						'primarycatid' => $primarycategory,
						);
				echo json_encode($success);
			}
		
				}
				
	/*Update Gcal Info*/
	public function service_finder_updateGcalInfo($arg){
			global $wpdb, $service_finder_Tables, $current_user;				
			
			require_once SERVICE_FINDER_BOOKING_LIB_DIR.'/google-api-php-client/src/Google/autoload.php';
			
			$google_client_id = (!empty($arg['google_client_id'])) ? $arg['google_client_id'] : '';
			$google_client_secret = (!empty($arg['google_client_secret'])) ? $arg['google_client_secret'] : '';
			$providerid = (!empty($arg['providerid'])) ? $arg['providerid'] : '';
			
			update_user_meta($providerid,'google_client_id',$google_client_id);
			update_user_meta($providerid,'google_client_secret',$google_client_secret);
			update_user_meta($providerid,'google_calendar_id',$google_calendar_id);
			
			$client_id = get_user_meta($providerid,'google_client_id',true);
			$client_secret = get_user_meta($providerid,'google_client_secret',true);
			$redirect_uri = add_query_arg( array('action' => 'googleoauth-callback'), home_url() );
			
			try{	
    		$client = new Google_Client();
			$client->setClientId($client_id);
			$client->setClientSecret($client_secret);
			$client->setRedirectUri($redirect_uri);
			$client->setScopes('https://www.googleapis.com/auth/calendar');	
			
			$authUrl = $client->createAuthUrl();
		    $connectlink = '<a href="'.esc_url($authUrl).'" class="btn btn-primary margin-r-10">'.esc_html__('Connect to Google Calendar', 'service-finder').'</a>';
			
			unset($_SESSION['access_token']);
			delete_user_meta($providerid,'gcal_access_token');
			delete_user_meta($providerid,'google_calendar_id');
			
			$success = array(
						'status' => 'success',
						'suc_message' => esc_html__('Google calendar info updated successfully.', 'service-finder'),
						'connectlink' => $connectlink,
						);
			echo json_encode($success);
			} catch (Exception $e) {
				$error = array(
						'status' => 'error',
						'err_message' => $e->getMessage()
						);
				echo json_encode($error);
			}
	}		
				
	/*Upload identity*/
	public function service_finder_uploadIdentity($arg){
			global $wpdb, $service_finder_Tables, $current_user;
			
			if(!empty($arg['identityattachmentid'])){
					foreach($arg['identityattachmentid'] as $identityattachmentid){
						if(!$this->service_finder_check_attachment($identityattachmentid)){
							$user_id = (!empty($arg['user_id'])) ? $arg['user_id'] : '';
							$data = array(
										'wp_user_id' => $user_id,
										'attachmentid' => $identityattachmentid,
										'type' => 'identity'
										);
					
							$wpdb->insert($service_finder_Tables->attachments,wp_unslash($data));	
							
							$wpdb->query($wpdb->prepare('UPDATE '.$service_finder_Tables->providers.' SET `identity` = "" WHERE `wp_user_id` = %d',$user_id));
						}
					}
				
					$msg = (!empty($service_finder_options['upload-identity'])) ? $service_finder_options['upload-identity'] : esc_html__('Your identity uploaded successfully. You can proceed once its approved by admin.', 'service-finder');
					$success = array(
							'status' => 'success',
							'suc_message' => $msg,
							'userid' => $userId,
							);
					echo json_encode($success);
				
				}else{
					$error = array(
							'status' => 'error',
							'err_message' => esc_html__('You don\'t have upload any identity proof. Please uplaod first', 'service-finder'),
							);
					echo json_encode($error);
				}
				
	}					
				
	/*Update Customer Profile*/
	public function service_finder_updateCustomerProfile($arg){
			global $wpdb, $service_finder_Tables;
			
			$user_email = (!empty($arg['user_email'])) ? $arg['user_email'] : '';
			$password = (!empty($arg['password'])) ? $arg['password'] : '';
			$first_name = (!empty($arg['first_name'])) ? $arg['first_name'] : '';
			$last_name = (!empty($arg['last_name'])) ? $arg['last_name'] : '';
			$phone = (!empty($arg['phone'])) ? $arg['phone'] : '';
			$phone2 = (!empty($arg['phone2'])) ? $arg['phone2'] : '';
			$address = (!empty($arg['address'])) ? $arg['address'] : '';
			$apt = (!empty($arg['apt'])) ? $arg['apt'] : '';
			$city = (!empty($arg['city'])) ? $arg['city'] : '';
			$state = (!empty($arg['state'])) ? $arg['state'] : '';
			$zipcode = (!empty($arg['zipcode'])) ? $arg['zipcode'] : '';
			$user_id = (!empty($arg['user_id'])) ? $arg['user_id'] : '';
			$country = (!empty($arg['country'])) ? $arg['country'] : '';
			$plavatar = (!empty($arg['plavatar'])) ? $arg['plavatar'] : '';
			
			//Email already exist
			if($this->service_finder_custom_email_exists( $user_email, $user_id )){
				$error = array(
						'status' => 'error',
						'err_message' => esc_html__('Email already exist', 'service-finder'),
						);
				echo json_encode($error);
				exit;
			}
		
			if($password != ""){
			$userdata = array(
						'ID' => $user_id,
						'user_email' => $user_email,
						'user_pass' => $password,
						'first_name' => $first_name,
						'last_name' => $last_name,
						);
			}else{
			$userdata = array(
						'ID' => $user_id,
						'user_email' => $user_email,
						'first_name' => $first_name,
						'last_name' => $last_name,
						);
			}			
			

			$userId = wp_update_user( $userdata );
			
			if ( ! empty($userId->errors) ) {
				$adminemail = get_option( 'admin_email' );
				$allowedhtml = array(
					'a' => array(
						'href' => array(),
						'title' => array()
					),
				);
				$error = array(
						'status' => 'error',
						'err_message' => sprintf( wp_kses(esc_html__('Couldn&#8217;t update you... please contact the <a href="mailto:%s">Administrator</a> !', 'service-finder'),$allowedhtml), $adminemail )
						);
				echo json_encode($error);
			}else{
			
				update_user_meta($userId, 'first_name', $first_name);
				update_user_meta($userId, 'last_name', $last_name);
				
				/*Update Customer Data Table*/
				$data = array(
						'phone' => $phone,
						'phone2' => $phone2,
						'address' => $address,
						'apt' => $apt,
						'city' => $city,
						'state' => $state,
						'zipcode' => $zipcode,
						'country' => $country,
						'avatar_id' => $plavatar
						);
				
				$where = array(
						'wp_user_id' => $userId,
						);
				$wpdb->update($service_finder_Tables->customers_data,wp_unslash($data),$where);		
				
				$success = array(
						'status' => 'success',
						'suc_message' => esc_html__('Your profile updated successfully.', 'service-finder'),
						'userid' => $userId,
						);
				echo json_encode($success);
			}
		
				}			
				
	/*Check email is exist or not*/
	function service_finder_custom_email_exists($email,$userid){
		global $wpdb;
		$table_name = $wpdb->prefix . 'users';
		$res = $wpdb->get_row($wpdb->prepare('SELECT ID from '.$table_name.' where `user_email` = "%s" and ID != %d',$email,$userid));
		return (!empty($res)) ? true : false;
	}
	
	/*Check If Gallery Image is attached already*/
	function service_finder_check_attachment($attachmentid){
		global $wpdb, $service_finder_Tables;
		$table_name = $wpdb->prefix . 'users';
		$res = $wpdb->get_row($wpdb->prepare('SELECT * from '.$service_finder_Tables->attachments.' where `attachmentid` = %d',$attachmentid));
		return (!empty($res)) ? true : false;
	}

}