<?php
/*****************************************************************************
*
*	copyright(c) - aonetheme.com - Service Finder Team
*	More Info: http://aonetheme.com/
*	Coder: Service Finder Team
*	Email: contact@aonetheme.com
*
******************************************************************************/

wp_enqueue_script('service_finder-js-bh-form');
$wpdb = service_finder_plugin_global_vars('wpdb');
$service_finder_Params = service_finder_plugin_global_vars('service_finder_Params');
$service_finder_Tables = service_finder_plugin_global_vars('service_finder_Tables');

$days = array('monday','tuesday','wednesday','thursday','friday','saturday','sunday');


?>
<!--Availability Template-->

<h4>
  <?php echo (!empty($service_finder_options['label-business-hours'])) ? esc_html($service_finder_options['label-business-hours']) : esc_html__('Business Hours', 'service-finder'); ?>
</h4>
<div class="profile-form-bx">
  <div class="auther-availability form-inr clearfix">
    <p>
      <?php esc_html_e('Set Up business hours for each week day', 'service-finder'); ?>
    </p>
    <div class="section-content">
      <div class="row">
        <form class="busihours" method="post">
        <div class="col-md-4">
        <div class="form-group">
        <?php 
            ?>
          <select class="form-control" name="busistarttime" data-live-search="true" title="<?php esc_html_e('Start Time', 'service-finder'); ?>">
            <option value=""><?php esc_html_e('Start Time', 'service-finder'); ?></option>
            <?php 
            $begin = new DateTime("00:00");
            $end   = new DateTime("24:00");
            
            $interval = DateInterval::createFromDateString('30 min');
            
            $times    = new DatePeriod($begin, $interval, $end);
            
            foreach ($times as $time) {
                if($time_format){
                    echo '<option value="'.$time->format('H:i').'">'.$time->format('H:i').'</option>';	 
                }else{
                    echo '<option value="'.$time->format('H:i').'">'.$time->format('h:i a').'</option>';
                }
            }
            ?>
          </select>  
        </div>
        </div>
              
        <div class="col-md-4">
        <div class="form-group">
          <select class="form-control" name="busiendtime" data-live-search="true" title="<?php esc_html_e('End Time', 'service-finder'); ?>">
            <option value=""><?php esc_html_e('End Time', 'service-finder'); ?></option>
            <?php 
            $begin = new DateTime("00:00");
            $end   = new DateTime("24:00");
            
            $interval = DateInterval::createFromDateString('30 min');
            
            $times    = new DatePeriod($begin, $interval, $end);
            
            foreach ($times as $time) {
                if($time_format){
                    echo '<option value="'.$time->format('H:i').'">'.$time->format('H:i').'</option>';	 
                }else{
                    echo '<option value="'.$time->format('H:i').'">'.$time->format('h:i a').'</option>';
                }
            }
            ?>
          </select>
        </div>
        </div> 
        
        <div class="col-md-4">
        <div class="form-group">
        <div class="checkbox">
                    <input type="checkbox" value="yes" name="busioffday" id="busioffday">
                    <label for="busioffday">
                    <?php esc_html_e('OFF', 'service-finder'); ?>
                    </label>
                  </div>
            <div class="input-group-btn">
                <button type="submit" class="btn btn-primary addbusihours"><i class="fa fa-plus"></i> <?php esc_html_e('Add','service-finder') ?></button>
                <?php
				$currentpageurl = service_finder_get_url_by_shortcode('[service_finder_my_account]');
				
				if(service_finder_getUserRole($current_user->ID) == 'administrator'){
				
				$currentpageurl = add_query_arg( array('manageaccountby' => 'admin','manageproviderid' => $globalproviderid,'tabname' => 'business-hours'), $currentpageurl );
				
				}else{
				
				$currentpageurl = add_query_arg( array('tabname' => 'business-hours'), $currentpageurl );
				
				}
				?>
                <a href="javascript:;" data-currentpage="<?php echo esc_attr($currentpageurl); ?>" class="btn btn-primary reloadbusihours"><i class="fa fa-refresh"></i> <?php esc_html_e('Reload','service-finder') ?></a>
            </div> 
        </div>
        </div>
        
        <?php 
        for($i = 0; $i <= 6; $i++){ 
        $year = date('Y'); 
        $weekdayname = date("l", mktime(0,0,0,8,$i,$year));
		
		switch(strtolower($weekdayname)){
		case 'monday':
			$weekdaynamestr = esc_html__('Monday','service-finder');
			break;
		case 'tuesday':
			$weekdaynamestr = esc_html__('Tuesday','service-finder');
			break;
		case 'wednesday':
			$weekdaynamestr = esc_html__('Wednesday','service-finder');
			break;
		case 'thursday':
			$weekdaynamestr = esc_html__('Thursday','service-finder');
			break;
		case 'friday':
			$weekdaynamestr = esc_html__('Friday','service-finder');
			break;
		case 'saturday':
			$weekdaynamestr = esc_html__('Saturday','service-finder');
			break;
		case 'sunday':
			$weekdaynamestr = esc_html__('Sunday','service-finder');
			break;						
		}
        ?>
    
        <div class="col-md-4">
          <div class="checkbox">
              <input type="checkbox" id="busi-<?php echo esc_attr(strtolower($weekdayname)); ?>" name="busiweekdays[]" value="<?php echo esc_attr(strtolower($weekdayname)); ?>">
              <label for="busi-<?php echo esc_attr(strtolower($weekdayname)); ?>"><?php echo esc_html($weekdaynamestr); ?></label>
            </div>
        </div>
    
        <?php } ?>       
    		<input type="hidden" name="user_id" value="<?php echo esc_attr($globalproviderid); ?>" />
        </form>
   	   </div>
    </div>
    <div class="tabbable tabs-left">
      <ul class="nav nav-tabs col-md-3 col-sm-3 padding-0" id="subTabHours">
        <?php foreach($days as $day){ 

                                                $class = ($day == 'monday') ? 'active' : '';
												switch($day){
												case 'monday':
													$dayname = esc_html__('Monday','service-finder');
													break;
												case 'tuesday':
													$dayname = esc_html__('Tuesday','service-finder');
													break;
												case 'wednesday':
													$dayname = esc_html__('Wednesday','service-finder');
													break;
												case 'thursday':
													$dayname = esc_html__('Thursday','service-finder');
													break;
												case 'friday':
													$dayname = esc_html__('Friday','service-finder');
													break;
												case 'saturday':
													$dayname = esc_html__('Saturday','service-finder');
													break;
												case 'sunday':
													$dayname = esc_html__('Sunday','service-finder');
													break;						
												}

												echo '<li class="'.sanitize_html_class($class).'"><a data-toggle="tab" href="#bh-'.$day.'">'.$dayname.'</a></li>';

                                                }?>
      </ul>
      <div class="tab-content col-md-9 col-sm-9 padding-0 business-hrs-min-in">
        <?php 

   

										   foreach($days as $day){
											$currUser = wp_get_current_user();
											$res = $wpdb->get_row($wpdb->prepare('SELECT * FROM '.$service_finder_Tables->business_hours.' where day = "%s" AND provider_id = %d',$day,$globalproviderid));		
											$from = '';
											$to = '';
											$check = '';
											if(!empty($res)){
											if($res->offday == 'yes'){
											$check = 'checked="checked"';
											}else{
											$check = '';
											}
											if($res->from_time != ""){
											$from = $res->from_time;
											}
											if($res->to_time != ""){
											$to = $res->to_time;
											}
											if($res->offday == 'yes'){
											$from = '';
											$to = '';
											}
											}
										   ?>
        <div id="bh-<?php echo esc_attr($day); ?>" class="tab-pane <?php echo ($day == 'monday') ? 'active' : '';?>">
          <div class="tabs-inr">
            <form class="form-business-hours input_pro_slots <?php echo esc_attr($day); ?>-timeslots" id="<?php echo esc_attr($day); ?>-business-hours" method="post">
              <div class="clearfix">
                  <div class="col-lg-6">
                      <label>
                      <?php esc_html_e('From', 'service-finder'); ?>
                      </label>
                        <select name="from_time">
                          <option value="">
                          <?php esc_html_e('Select Time', 'service-finder'); ?>
                          </option>
                          <?php service_finder_getHours($from); ?>
                        </select>
                  </div>
                  <div class="col-lg-6">
                      <label>
                      <?php esc_html_e('To', 'service-finder'); ?>
                      </label>
                        <select name="to_time">
                          <option value="">
                          <?php esc_html_e('Select Time', 'service-finder'); ?>
                          </option>
                          <?php service_finder_getHours($to); ?>
                        </select>
                  </div>
              </div>
              <br />
              <div class="col-lg-12">
                <div class="form-group form-inline">
                  <div class="checkbox">
                    <input <?php echo esc_attr($check); ?> type="checkbox" value="yes" name="offday" id="<?php echo esc_attr($day); ?>-offday">
                    <label for="<?php echo esc_attr($day); ?>-offday">
                    <?php esc_html_e('OFF', 'service-finder'); ?>
                    </label>
                  </div>
                </div>
              </div>
              <input type="hidden" name="user_id" value="<?php echo esc_attr($globalproviderid); ?>" />
              <div class="col-lg-12">
                <div class="form-group">
                  <button class="btn btn-primary margin-r-10" name="Save" type="submit" >
                  <?php esc_html_e('Submit', 'service-finder'); ?>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
        <?php

										   }

										   ?>
      </div>
    </div>
  </div>
</div>
