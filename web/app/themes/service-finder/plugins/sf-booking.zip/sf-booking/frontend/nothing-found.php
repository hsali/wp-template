<?php
/*****************************************************************************
*
*	copyright(c) - aonetheme.com - Service Finder Team
*	More Info: http://aonetheme.com/
*	Coder: Service Finder Team
*	Email: contact@aonetheme.com
*
******************************************************************************/

?>
<!-- Template for nothing found -->

<div class="sf-nothing-found"> <strong class="sf-tilte">
  <?php esc_html_e('Nothing Found', 'service-finder'); ?>
  </strong>
  <p>
    <?php esc_html_e('Apologies, but no results were found for the request.', 'service-finder'); ?>
  </p>
</div>
'; 