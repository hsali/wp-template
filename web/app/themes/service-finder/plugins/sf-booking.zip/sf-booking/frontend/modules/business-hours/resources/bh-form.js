/*****************************************************************************
*
*	copyright(c) - aonetheme.com - Service Finder Team
*	More Info: http://aonetheme.com/
*	Coder: Service Finder Team
*	Email: contact@aonetheme.com
*
******************************************************************************/

// When the browser is ready...
  jQuery(function() {
	'use strict';
	
	var dayname = 'Mon';
	var tabname = 'monday';
	var mflag = 0;
	var tflag = 0;
	var wflag = 0;
	var thflag = 0;
	var frflag = 0;
	var saflag = 0;
	var suflag = 0;
	/*Click event on subtabs*/
	jQuery('body').on('click', '#subTabHours li a', function(){
		dayname = jQuery(this).attr('href');													
		dayname = dayname.replace("#bh-", "");
		tabname = dayname;
		dayname = dayname.replace("day", "");
		dayname = dayname.substr(0, 1).toUpperCase() + dayname.substr(1);
	});
	
	jQuery('form').on('change', 'select[name="busistarttime"]', function(){
		var $select_starttime = jQuery('select[name="busistarttime"]');
		var $select_endtime = jQuery('select[name="busiendtime"]');
		var start_time       = jQuery(this).val(),
			end_time         = $select_starttime.val(),
			$last_time_entry = jQuery('option:last', $select_starttime);

		$select_endtime.empty();
		$select_endtime.append('<option value="">'+param.endtime+'</option>');
		// case when we click on the not last time entry
		if ($select_starttime[0].selectedIndex < $last_time_entry.index()) {
			// clone and append all next "time_from" time entries to "time_to" list
			jQuery('option', this).each(function () {
				
				if (jQuery(this).val() > start_time) {
					if(jQuery(this).prop('disabled')){
						return false;
					}
					$select_endtime.append(jQuery(this).clone());
				}
				
			});
		// case when we click on the last time entry
		} else {
			$select_endtime.append($last_time_entry.clone()).val($last_time_entry.val());
		}

		var first_value = jQuery('option:first', $select_endtime).val();
		$select_endtime.val(end_time >= first_value ? end_time : first_value);
		jQuery('select[name="busiendtime"] option:last').attr('selected','selected');
		jQuery('select').selectpicker('refresh');
                        
	});
	
	if(busitab == "yes"){
		jQuery('#myTab a[href="#business-hours"]').tab('show');	
	}
	
	jQuery('body').on('click', 'a.reloadbusihours', function(){
		var currentpage= jQuery(this).data('currentpage');
		window.location = currentpage;
	});
	
	//Add Regions
    jQuery('.busihours')
        .bootstrapValidator({
            message: param.not_valid,
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
				busistarttime: {
					validators: {
						notEmpty: {
							message: param.req
						}
					}
				},
				busiendtime: {
					validators: {
						notEmpty: {
							message: param.req
						}
					}
				},
            }
        })
        .on('success.form.bv', function(form) {
			jQuery('form.busihours').find('button[type="submit"]').prop('disabled', false);											
            // Prevent form submission
			form.preventDefault();
			 
			var busistarttime = jQuery('select[name="busistarttime"]').val();
			var busiendtime = jQuery('select[name="busiendtime"]').val();
			var busioffday = jQuery('input[name="busioffday"]:checked').val();
			var wdays = jQuery('input[name="busiweekdays[]"]:checked').val();
			
			if(busioffday != 'yes'){
			if(busistarttime == ''){
				jQuery(".alert-danger").remove();
				jQuery( "<div class='alert alert-danger'>"+param.select_starttime+"</div>" ).insertBefore( "form.busihours" );
				return false;
			}
			
			if(busiendtime == ''){
				jQuery(".alert-danger").remove();
				jQuery( "<div class='alert alert-danger'>"+param.select_endtime+"</div>" ).insertBefore( "form.busihours" );
				return false;
			}
			}
			
			if(wdays == undefined){
				jQuery(".alert-danger").remove();
				jQuery( "<div class='alert alert-danger'>"+param.select_weekday+"</div>" ).insertBefore( "form.busihours" );
				return false;
			}
			
            // Get the form instance
            var $form = jQuery(form.target);
            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');
			
			var data = {
			  "action": "add_busi_hours",
			};
			
			var formdata = jQuery($form).serialize() + "&" + jQuery.param(data);
			
			jQuery.ajax({

						type: 'POST',

						url: ajaxurl,
						
						dataType: "json",
						
						beforeSend: function() {
							jQuery(".alert-success").remove();
							jQuery(".alert-danger").remove();
							jQuery('.loading-area').show();
						},
						
						data: formdata,

						success:function (data, textStatus) {
							jQuery('.loading-area').hide();
							$form.find('button[type="submit"]').prop('disabled', false);
							if(data['status'] == 'success'){
								jQuery('select').selectpicker('refresh');
								jQuery('input[name="busiweekdays[]"]').attr('checked', false);
								jQuery('form.busihours').bootstrapValidator('resetForm',true);
								jQuery('select').selectpicker('refresh');
								jQuery( "<div class='alert alert-success'>"+data['suc_message']+"</div>" ).insertBefore( "form.busihours" );
								window.setTimeout(function(){
									jQuery(".alert-success").remove();
									jQuery(".alert-danger").remove();
								}, 2000);
							}else if(data['status'] == 'error'){
								jQuery( "<div class='alert alert-danger'>"+data['err_message']+"</div>" ).insertBefore( "form.busihours" );
							}
							
							
						
						}

					});
			
    });
	
	//Save Business Hours
	jQuery('.form-business-hours')
        .bootstrapValidator({
            message: param.not_valid,
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {}
        })
		.on('error.field.bv', function(e, data) {
            data.bv.disableSubmitButtons(false); // disable submit buttons on errors
	    })
		.on('status.field.bv', function(e, data) {
            data.bv.disableSubmitButtons(false); // disable submit buttons on valid
        })
        .on('success.form.bv', function(form) {
            // Prevent form submission
			
            form.preventDefault();

            // Get the form instance
            var $form = jQuery(form.target);
            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');
			
			var data = {
			  "action": "save_businesshours",
			  "day": tabname,
			};
			
			var formdata = jQuery($form).serialize() + "&" + jQuery.param(data);
			
			jQuery.ajax({

						type: 'POST',

						url: ajaxurl,
						
						dataType: "json",
						
						beforeSend: function() {
							jQuery(".alert").remove();
							jQuery('.loading-area').show();
						},
						
						data: formdata,

						success:function (data, textStatus) {
							jQuery('.loading-area').hide();
							$form.find('button[type="submit"]').prop('disabled', false);
							if(data['status'] == 'success'){
								jQuery( "<div class='alert alert-success'>"+data['suc_message']+"</div>" ).insertBefore( "#"+tabname+"-business-hours" );	
										
							}else if(data['status'] == 'error'){
								jQuery( "<div class='alert alert-danger'>"+data['err_message']+"</div>" ).insertBefore( "#"+tabname+"-business-hours" );
							}
							
						}

					});
			
        });
	
  });